# checks whether your camera might have been affected
# by a null pointer bug from the 2017Apr04 ML build.
# updated Apr10 2017 (ignore some false warnings)

from __future__ import print_function
import os, sys
from struct import unpack

def getLongLE(d, a):
   return unpack('<L',d[a:a+4])[0]

try:
    ROM = open(sys.argv[1], "rb").read()
except IndexError:
    print("usage:")
    print("1) Backup the contents of ML/LOGS from your card")
    print("2) Debug -> Dump ROM and RAM (to get a new ROM copy)")
    print("3) Run this command on the latest copy of your ROM:")
    print("   python %s ROM1.BIN" % sys.argv[0])
    raise SystemExit

# scan for the magic number 0xA5A5A5A5 that might have been
# written into ROM as a result of the null pointer bug
found = 0
ignored = 0
can_ignore = False
ignore_msg = ""
gaonisoy = False
for a in range(0, len(ROM)-4, 4):
    v = getLongLE(ROM, a)
    n = getLongLE(ROM, a+4)
    block_name = ""
    can_ignore = False
    if a >= 0xF40000 and a < 0xF80000:      # RING - that's where most errors were
        a0 = a & ~0xFFF                     # header of this block
        if getLongLE(ROM, a0) == 0xFFFF:    # active block? only check this one
            block_name = "active RING"
            if a == a0:
                print("Active RING block: %x-%x" % (a0, a0+0xFFF))
        else:
            block_name = "inactive RING"
            can_ignore = True               # ignore inactive RING blocks
    if a >= 0xF80000 and a < 0xFA0000:      # last debug log - ignore
        block_name = "last debug log"
        can_ignore = True
    if v == 0xA5A5A5A5 and n != 0xE5E5E5E5:
        print(hex(a), hex(v), block_name)
        found   += (0 if can_ignore else 1)
        ignored += (1 if can_ignore else 0)
    if v == 0x6E6F6167 and n == 0x796F7369:
        assert a == 0xC0004
        gaonisoy = True

print("\nErrors found: %d, ignored: %d." % (found, ignored))

if not gaonisoy:
    print("Doesn't look like a valid ROM1 dump.")
elif found > 0:
    print("Your camera might have been affected by the Apr04 null pointer bug.")
    print("Please contact Magic Lantern developers on IRC (#magiclantern on freenode)")
    print("to take a closer look.")
else:
    print("Your camera appears OK, no need to worry.")

